import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

// ✅ Así cargamos el archivo .json sin el problema del "assert"
const serviceAccount = require('./proyecto-mlg-firebase-adminsdk-fbsvc-ed2e842228.json');

initializeApp({
  credential: cert(serviceAccount),
});

const db = getFirestore();

export default db;